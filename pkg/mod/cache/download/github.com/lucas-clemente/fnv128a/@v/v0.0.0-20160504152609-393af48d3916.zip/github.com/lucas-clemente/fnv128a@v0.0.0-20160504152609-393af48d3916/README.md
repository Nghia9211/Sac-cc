# fnv128a

Implementation of the FNV-1a 128bit hash in go
