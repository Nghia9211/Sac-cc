package nolabels_test

import (
	. "github.com/onsi/ginkgo/v2"
)

var _ = Describe("Nolabels", func() {

})
