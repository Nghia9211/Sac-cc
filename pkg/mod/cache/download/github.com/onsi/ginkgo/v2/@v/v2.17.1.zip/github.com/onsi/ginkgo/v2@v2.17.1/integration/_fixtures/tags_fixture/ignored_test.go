// +build complex_tests

package tags_test

import (
	. "github.com/onsi/ginkgo/v2"
)

var _ = Describe("Ignored", func() {
	It("should not have these tests", func() {

	})

	It("should not have these tests", func() {

	})
})
