package A

import "github.com/onsi/ginkgo/v2/integration/_fixtures/watch_fixture/B"

func DoIt() string {
	return B.DoIt()
}
